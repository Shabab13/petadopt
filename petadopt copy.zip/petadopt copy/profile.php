<?php
session_start();
include 'db.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get the logged-in user's information
$userID = $_SESSION['user_id'];
$sql = "SELECT * FROM Users WHERE UserID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userID);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Get the pets added by the user
$sql_pets = "SELECT * FROM Pets WHERE UserID = ?";
$stmt_pets = $conn->prepare($sql_pets);
$stmt_pets->bind_param("i", $userID);
$stmt_pets->execute();
$pets_result = $stmt_pets->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($user['FirstName']); ?>'s Profile</title>
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body Styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #eaf0e7;
            color: #333;
        }

        /* Navbar Styling */
        nav {
            display: flex;
            justify-content: space-between;
            background-color: #2d6a4f;
            padding: 10px 20px;
        }

        nav .logo h1 {
            color: white;
        }

        nav .nav-links {
            display: flex;
            list-style: none;
        }

        nav .nav-links li {
            margin-left: 20px;
        }

        nav .nav-links a {
            color: white;
            text-decoration: none;
        }

        nav .nav-links a:hover {
            color: #a0d6a0;
        }

        /* Profile Container */
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            max-width: 700px;
            margin: 50px auto;
            text-align: center;
        }

        .container h2 {
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
        }

        .container p {
            margin: 5px 0;
            color: #555;
        }

        .pets-list {
            list-style: none;
            padding: 0;
            margin-top: 20px;
        }

        .pets-list li {
            background-color: #f9f9f9;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 6px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }

        .btn {
            background-color: #2d6a4f;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 4px;
            display: inline-block;
            margin-right: 10px;
            margin-top: 20px;
        }

        .btn:hover {
            background-color: #1b3a28;
        }

        footer {
            background-color: #2d6a4f;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

    <!-- Navigation Bar -->
    <nav>
        <div class="logo">
            <h1>PicPaw</h1>
        </div>
        <ul class="nav-links">
            <li><a href="view_pets.php">Find Adoptions</a></li>
            <li><a href="add_pet.php">Post Adoptions</a></li>
            <li><a href="about.php">About Us</a></li>

            <?php if(isset($_SESSION['user_id'])): ?>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Sign Up</a></li>
            <?php endif; ?>
        </ul>
    </nav>

    <!-- Profile Section -->
    <div class="container">
        <h2><?php echo htmlspecialchars($user['FirstName'] . " " . $user['LastName']); ?>'s Profile</h2>

        <p><strong>Email:</strong> <?php echo htmlspecialchars($user['Email']); ?></p>
        <p><strong>Phone Number:</strong> <?php echo htmlspecialchars($user['PhoneNumber']); ?></p>
        <p><strong>Location:</strong> <?php echo htmlspecialchars($user['Address']); ?></p>

        <h3>Your Pets for Adoption</h3>
        <ul class="pets-list">
            <?php if ($pets_result->num_rows > 0): ?>
                <?php while ($pet = $pets_result->fetch_assoc()): ?>
                    <li>
                        <strong><?php echo htmlspecialchars($pet['Name']); ?></strong>
                        (<?php echo htmlspecialchars($pet['Category']); ?>),
                        Age: <?php echo htmlspecialchars($pet['Age']); ?>
                    </li>
                <?php endwhile; ?>
            <?php else: ?>
                <li>No pets available for adoption yet.</li>
            <?php endif; ?>
        </ul>

        <a href="add_pet.php" class="btn">Add New Pet</a>
        <a href="logout.php" class="btn">Logout</a>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 PicPaw. All rights reserved.</p>
    </footer>

</body>
</html>