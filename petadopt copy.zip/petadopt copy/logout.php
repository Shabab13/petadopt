<?php
session_start();
session_destroy();  // Destroy all session data

// Redirect to the homepage or login page after logging out
header("Location: index.php");
exit();