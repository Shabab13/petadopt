<?php
include 'db.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userID = $_SESSION['user_id'];
    $vetID = $_POST['vet_id'];
    $appointmentDate = $_POST['appointment_date'];
    $reason = $_POST['reason'];

    $sql = "INSERT INTO VetAppointment (UserID, VetID, AppointmentDate, Reason) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiss", $userID, $vetID, $appointmentDate, $reason);

    if ($stmt->execute()) {
        echo "Appointment booked!";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>