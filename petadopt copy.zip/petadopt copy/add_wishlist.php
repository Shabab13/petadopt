<?php
include 'db.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userID = $_SESSION['user_id'];
    $category = $_POST['category'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];

    $sql = "INSERT INTO Wishlist (UserID, Catagory, Gender, Age) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isss", $userID, $category, $gender, $age);

    if ($stmt->execute()) {
        echo "Added to wishlist!";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>